document.getElementById("loginBtn").addEventListener("click", function() {
    window.location.href = "login.html"; // Redirect to login page
});

document.getElementById("signupBtn").addEventListener("click", function() {
    window.location.href = "signup.html"; // Redirect to sign up page
});

document.getElementById("loginBackBtn").addEventListener("click", function() {
    window.location.href = "index.html"; // Redirect to index.html
});


